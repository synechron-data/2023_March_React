import React from 'react';

const ComponentTwo = () => {
    return (
        <h2 className="text-primary">Hello from Component Two</h2>
    );
};

export default ComponentTwo;