import React from 'react';

import './ComponentTwo.css'

const ComponentTwo = () => {
    return (
        <>
            <h2 className="text-primary">Hello from Component Two</h2>
            <h2 className='card2'>From Component Two</h2>
        </>
    );
};

export default ComponentTwo;