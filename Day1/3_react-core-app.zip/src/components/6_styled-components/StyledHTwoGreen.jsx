import styled from 'styled-components';

const StyledHTwoGreen = styled.h2`
    margin: 1em;
    padding-left: 0;
    border: 2px dashed green;
`;

export default StyledHTwoGreen;