import styled from 'styled-components';

const StyledHTwoBlue = styled.h2`
    margin: 1em;
    padding-left: 0;
    border: 2px solid blue;
`;

export default StyledHTwoBlue;