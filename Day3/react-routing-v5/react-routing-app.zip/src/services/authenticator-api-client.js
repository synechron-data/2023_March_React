const authenticatorClient = {
    isAuthenticated: false
};

export default authenticatorClient;