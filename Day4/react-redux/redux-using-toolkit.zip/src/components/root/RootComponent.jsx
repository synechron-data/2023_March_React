import React from 'react';
import CounterComponent from '../counter/CounterComponent';

const RootComponent = () => {
    return (
        <div className='container'>
            <CounterComponent />
        </div>
    );
};

export default RootComponent;