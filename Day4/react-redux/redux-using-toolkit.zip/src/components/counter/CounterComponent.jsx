import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
    decrement,
    decrementAsync,
    decrementBy,
    increment,
    incrementAsync,
    incrementBy,
    selectCount
} from '../../features/counter/counterSlice';

import styles from './CounterComponent.module.css';

const CounterComponent = () => {
    const count = useSelector(selectCount);
    const dispatch = useDispatch();
    const [amount, setAmount] = useState('2');

    return (
        <>
            <div className="text-center">
                <h1 className="text-info">Counter Component</h1>
            </div>
            <div className="d-grid gap-2 mx-auto col-6">
                <h3>Increment / Decrement By 1</h3>
                <h2 className="text-primary text-center">
                    Current Count: {count}
                </h2>
                <button className="btn btn-primary" onClick={() => dispatch(increment())}>
                    <span className='fs-4'>+</span>
                </button>
                <button className="btn btn-primary" onClick={() => dispatch(decrement())}>
                    <span className='fs-4'>-</span>
                </button>
            </div>
            <div className="d-grid gap-2 mx-auto col-6 mt-3">
                <h3>Increment / Decrement By Amount</h3>
                <input
                    className="form-control"
                    value={amount}
                    onChange={e => setAmount(e.target.value)}
                />
                <button
                    className="btn btn-primary"
                    onClick={() =>
                        dispatch(incrementBy(Number(amount) || 0))
                    }
                >
                    <span className='fs-4'>Increment By {amount}</span>
                </button>
                <button
                    className="btn btn-primary"
                    onClick={() =>
                        dispatch(decrementBy(Number(amount) || 0))
                    }
                >
                    <span className='fs-4'>Decrement By {amount}</span>
                </button>
            </div>
            <div className="d-grid gap-2 mx-auto col-6 mt-3">
                <h3>Async Increment / Decrement </h3>
                <button
                    className={`${styles.asyncButton} btn btn-warning`}
                    onClick={() =>
                        dispatch(incrementAsync(Number(amount) || 0))
                    }
                >
                    <span className='fs-4'>Async Increment By {amount}</span>
                </button>
                <button
                    className={`${styles.asyncButton} btn btn-warning`}
                    onClick={() =>
                        dispatch(decrementAsync(Number(amount) || 0))
                    }
                >
                    <span className='fs-4'>Async Decrement By {amount}</span>
                </button>
            </div>
        </>
    );
};

export default CounterComponent;